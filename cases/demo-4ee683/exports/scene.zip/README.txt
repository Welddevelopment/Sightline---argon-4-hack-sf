SIGHTLINE SCENE EXPORT - Car into turning tractor-semitrailer at an uncontrolled median crossover, US-27A near Williston, Florida (2016)

*** ANALYSIS DRAFT - NOT EVIDENCE. Simulated reconstruction for review by a qualified expert.
*** FICTIONAL WITNESSES: witness names, positions and testimony in this case are fictional.
*** Witness eye views are simulated from marked positions; they are not what any witness actually saw.
*** Kinematic reconstruction: motion fitted to cited evidence; not a crash-physics simulation.

Case: demo    World: /cases/demo/worlds/world_v2.js    Exported: 2026-10-25T19:14:01.523Z
scene.glb is posed at t = 9.9 s (observation time of wit_B (finding F1, contradiction)); timeline 0..22.4 s.

FILES
  scene.glb   glTF 2.0 binary. Node names = world object ids (veh_, occ_, sig_, road_, mark_, bld_ ...).
              Labels, citations, kind, inferred flag and signal state are in each node's glTF "extras"
              (Blender: Object Properties > Custom Properties). Scene extras hold case meta + labels.
              Cameras cam_<witness id>: witness eye position, 60 deg vertical FOV, 16:9, aimed at the witness's lookAt target at t.
              Animation "timeline": 10 Hz position/rotation keys for moving objects (time in seconds).
              Lights are not included (sun direction is in scene extras).
  scene.json  meta, objects (id, label, citation, pose at t, keyframes sampled at 10 Hz over [0, duration]),
              witnesses (eye, lookAt, claim, citations, camera, sightline check), facts, skids, confirmed facts /
              extraction (if present), findings, checks + validation, provenance (hashes, model, inputs).

UNITS AND AXES
  meters, seconds, m/s, degrees.
  -Z = north, +X = east, Y = up, ground at y = 0. (Blender glTF import: +X east, +Y north, Z up.)
  bearingDeg = compass bearing of the object's forward (local -Z) axis: 0 north, 90 east.
  Citations containing "inferred" are modelling assumptions, not cited evidence.

This file is an analysis draft produced by software for review by a qualified reconstruction expert.
It is not evidence and has not been validated for court use.
